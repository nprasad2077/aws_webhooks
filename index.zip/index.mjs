import axios from 'axios'

export const handler = async (event) => {
    // Parse the incoming GitHub webhook payload
    const githubData = JSON.parse(event.body);

    // Check if the event is a new issue being opened
    if (githubData.action === 'opened' && githubData.issue) {
        const issueTitle = githubData.issue.title;
        const issueUrl = githubData.issue.html_url;

        // Format the message for Synology Chat
        const synologyMessage = {
            text: `New issue opened: [${issueTitle}](${issueUrl})`
        };

        // Send the message to Synology Chat
        await axios.post('https://doctasmooth.synology.me:5001/chat/webapi/entry.cgi?api=SYNO.Chat.External&method=incoming&version=2&token=%22jaf89ziCghkqkHz2wWAq2xpFVPkME0shbvstoxArqtZxQ93eTRdxa59yUZ7nbiUu%22', synologyMessage);
    }

    // Respond to the webhook sender (GitHub in this case)
    return {
        statusCode: 200,
        body: JSON.stringify('Webhook processed successfully!'),
    };
};
